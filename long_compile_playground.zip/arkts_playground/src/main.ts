
class A {
    a: number
}

function foo<T>(value: object): boolean {
    return value instanceof T
}

console.log(
    foo<string>(new A())
)